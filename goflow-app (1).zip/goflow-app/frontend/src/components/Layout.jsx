import { Outlet, NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth.jsx'
import styles from './Layout.module.css'

const NAV = [
  { to: '/',          icon: '📊', label: 'Dashboard',      end: true },
  { to: '/overrides', icon: '🔀', label: 'Trend Overrides' },
  { to: '/history',   icon: '📋', label: 'P&L History'     },
  { to: '/import',    icon: '📥', label: 'Import Data'      },
  { to: '/settings',  icon: '⚙️', label: 'Settings'        },
]

export default function Layout() {
  const { user, logout } = useAuth()
  const nav = useNavigate()

  const handleLogout = () => { logout(); nav('/login') }

  return (
    <div className={styles.wrap}>
      <aside className={styles.sidebar}>
        <div className={styles.logo}>
          <span className={styles.logoIcon}>📦</span>
          <div>
            <div className={styles.logoName}>GoFlow</div>
            <div className={styles.logoSub}>Inventory Manager</div>
          </div>
        </div>

        <nav className={styles.nav}>
          {NAV.map(n => (
            <NavLink
              key={n.to} to={n.to} end={n.end}
              className={({ isActive }) => `${styles.navItem} ${isActive ? styles.active : ''}`}
            >
              <span className={styles.navIcon}>{n.icon}</span>
              {n.label}
            </NavLink>
          ))}
        </nav>

        <div className={styles.userSection}>
          <div className={styles.avatar}>{(user?.name || user?.email || 'U')[0].toUpperCase()}</div>
          <div className={styles.userInfo}>
            <div className={styles.userName}>{user?.name || user?.email}</div>
            <div className={styles.userRole}>{user?.role}</div>
          </div>
          <button className={styles.logoutBtn} onClick={handleLogout} title="Sign out">↩</button>
        </div>
      </aside>

      <main className={styles.main}>
        <Outlet />
      </main>
    </div>
  )
}
