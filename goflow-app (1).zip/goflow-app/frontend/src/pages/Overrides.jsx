// Overrides.jsx
import { useState, useEffect } from 'react'
import api from '../hooks/useApi.js'
import s from './Pages.module.css'

export function Overrides() {
  const [overrides, setOverrides] = useState([])
  const [form, setForm] = useState({ item_number:'', borrow_from:'', notes:'' })
  const [msg, setMsg] = useState('')

  const load = () => api.get('/trends/overrides').then(setOverrides)
  useEffect(() => { load() }, [])

  const save = async () => {
    if (!form.item_number || !form.borrow_from) return
    await api.post('/trends/overrides', form)
    setMsg('Saved!'); setTimeout(() => setMsg(''), 2000)
    setForm({ item_number:'', borrow_from:'', notes:'' })
    load()
  }

  const del = async (item) => {
    await api.delete(`/trends/overrides/${item}`)
    load()
  }

  return (
    <div className={s.page}>
      <h1 className={s.title}>🔀 Trend Overrides</h1>
      <p className={s.sub}>Assign seasonal curves from other items to new or no-history items</p>

      {msg && <div className={s.success}>✅ {msg}</div>}

      <div className={s.card}>
        <h3 className={s.cardTitle}>Add / Update Override</h3>
        <div className={s.formRow}>
          <div className={s.field}>
            <label>Item # (assign trend to)</label>
            <input placeholder="e.g. 5670" value={form.item_number} onChange={e => setForm(f=>({...f,item_number:e.target.value}))} />
          </div>
          <div className={s.field}>
            <label>Borrow trend from</label>
            <input placeholder="e.g. 1430" value={form.borrow_from} onChange={e => setForm(f=>({...f,borrow_from:e.target.value}))} />
          </div>
          <div className={s.field} style={{flex:1}}>
            <label>Notes (optional)</label>
            <input placeholder="e.g. Similar product to 1430" value={form.notes} onChange={e => setForm(f=>({...f,notes:e.target.value}))} />
          </div>
          <button className={s.btnOrange} onClick={save}>+ Save</button>
        </div>
      </div>

      <div className={s.tableWrap}>
        <table className={s.table}>
          <thead><tr><th>Item #</th><th>Borrows From</th><th>Notes</th><th>Added By</th><th></th></tr></thead>
          <tbody>
            {overrides.length === 0
              ? <tr><td colSpan={5} className={s.empty}>No overrides set yet</td></tr>
              : overrides.map(o => (
                <tr key={o.item_number}>
                  <td><span className={s.accent}>{o.item_number}</span></td>
                  <td><span className={s.badgeOrange}>↗ {o.borrow_from}</span></td>
                  <td className={s.muted}>{o.notes || '—'}</td>
                  <td className={s.muted}>{o.created_by || '—'}</td>
                  <td><button className={s.btnDanger} onClick={() => del(o.item_number)}>Remove</button></td>
                </tr>
              ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

export default Overrides
