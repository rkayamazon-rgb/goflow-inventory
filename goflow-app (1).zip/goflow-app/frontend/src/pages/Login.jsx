import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { useAuth } from '../hooks/useAuth.jsx'
import api from '../hooks/useApi.js'
import s from './Login.module.css'

export default function Login() {
  const [email, setEmail] = useState('admin@company.com')
  const [password, setPassword] = useState('admin123')
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)
  const { login } = useAuth()
  const nav = useNavigate()

  const submit = async e => {
    e?.preventDefault()
    setLoading(true); setError('')
    try {
      const data = await api.post('/auth/login', { email, password })
      login(data.token, data.user)
      nav('/')
    } catch (e) {
      setError(e.error || 'Login failed')
    } finally { setLoading(false) }
  }

  return (
    <div className={s.wrap}>
      <div className={s.card}>
        <div className={s.brand}>
          <span className={s.brandIcon}>📦</span>
          <div>
            <div className={s.brandName}>GoFlow</div>
            <div className={s.brandSub}>Inventory Management</div>
          </div>
        </div>

        <h1 className={s.title}>Sign in</h1>

        {error && <div className={s.error}>{error}</div>}

        <form onSubmit={submit}>
          <div className={s.field}>
            <label>Email address</label>
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} autoFocus />
          </div>
          <div className={s.field}>
            <label>Password</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} />
          </div>
          <button className={s.btn} type="submit" disabled={loading}>
            {loading ? <span className="spin">⟳</span> : 'Sign in →'}
          </button>
        </form>

        <div className={s.hint}>
          <strong>Demo credentials</strong><br />
          admin@company.com / admin123<br />
          team@company.com / team123
        </div>
      </div>
    </div>
  )
}
