import { useState, useEffect } from 'react'
import api from '../hooks/useApi.js'
import s from './Pages.module.css'

export default function Settings() {
  const [cfg, setCfg] = useState({
    forecast_start_day:'1', forecast_end_day:'90',
    overstock_threshold_days:'180', velocity_from:'', velocity_to:'',
    velocity_mode:'Highest'
  })
  const [users, setUsers] = useState([])
  const [newUser, setNewUser] = useState({ email:'', password:'', name:'', role:'member' })
  const [msg, setMsg] = useState('')

  useEffect(() => {
    api.get('/inventory/settings').then(setCfg)
    api.get('/auth/users').catch(() => {})
      .then(u => u && setUsers(u))
  }, [])

  const saveSettings = async () => {
    await api.put('/inventory/settings/update', cfg)
    setMsg('Settings saved!'); setTimeout(() => setMsg(''), 2000)
  }

  const addUser = async () => {
    if (!newUser.email || !newUser.password) return
    await api.post('/auth/register', newUser)
    setMsg('User added!'); setTimeout(() => setMsg(''), 2000)
    setNewUser({ email:'', password:'', name:'', role:'member' })
    api.get('/auth/users').catch(()=>{}).then(u => u && setUsers(u))
  }

  const set = (k, v) => setCfg(c => ({...c, [k]: v}))
  const dur = parseInt(cfg.forecast_end_day) - parseInt(cfg.forecast_start_day) + 1

  return (
    <div className={s.page}>
      <h1 className={s.title}>⚙️ Settings</h1>
      <p className={s.sub}>Configure forecast window, velocity periods, and thresholds</p>

      {msg && <div className={s.success}>✅ {msg}</div>}

      <div className={s.settingsGrid}>
        <div className={s.card}>
          <h3 className={s.cardTitle}>📅 Forecast Window</h3>
          <div className={s.settingRow}>
            <span>Start Day</span>
            <input className={s.numInput} type="number" value={cfg.forecast_start_day} onChange={e=>set('forecast_start_day',e.target.value)} />
          </div>
          <div className={s.settingRow}>
            <span>End Day</span>
            <input className={s.numInput} type="number" value={cfg.forecast_end_day} onChange={e=>set('forecast_end_day',e.target.value)} />
          </div>
          <div className={s.settingRow}>
            <span>Duration</span>
            <span style={{color:'var(--accent-l)',fontWeight:700}}>{dur} days</span>
          </div>
          <button className={s.saveBtn} onClick={saveSettings}>Save</button>
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>⚡ Velocity Period</h3>
          <p style={{fontSize:12,color:'var(--muted)',marginBottom:14}}>
            Date range your pasted velocity data covers — used for trend % comparison
          </p>
          <div className={s.settingRow}>
            <span>From</span>
            <input className={s.dateInput} type="date" value={cfg.velocity_from||''} onChange={e=>set('velocity_from',e.target.value)} />
          </div>
          <div className={s.settingRow}>
            <span>To</span>
            <input className={s.dateInput} type="date" value={cfg.velocity_to||''} onChange={e=>set('velocity_to',e.target.value)} />
          </div>
          <button className={s.saveBtn} onClick={saveSettings}>Save</button>
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>🔴 Overstock Threshold</h3>
          <div className={s.settingRow}>
            <span>Flag when SOH covers more than</span>
            <input className={s.numInput} type="number" value={cfg.overstock_threshold_days} onChange={e=>set('overstock_threshold_days',e.target.value)} />
          </div>
          <div className={s.settingRow}>
            <span>days of current velocity</span>
            <span style={{color:'var(--red)',fontWeight:700}}>{cfg.overstock_threshold_days} days</span>
          </div>
          <button className={s.saveBtn} onClick={saveSettings}>Save</button>
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>👥 Team Members</h3>
          {users.map(u => (
            <div key={u.id} className={s.userRow}>
              <div className={s.userAvatar}>{(u.name||u.email)[0].toUpperCase()}</div>
              <div>
                <div style={{fontWeight:600,fontSize:13}}>{u.name || u.email}</div>
                <div style={{fontSize:11,color:'var(--muted)'}}>{u.email} · {u.role}</div>
              </div>
            </div>
          ))}
          <div style={{marginTop:16,paddingTop:16,borderTop:'1px solid var(--border2)'}}>
            <div style={{fontSize:12,fontWeight:600,color:'var(--muted)',marginBottom:10}}>ADD TEAM MEMBER</div>
            <div className={s.field} style={{marginBottom:8}}>
              <label>Name</label>
              <input placeholder="Full name" value={newUser.name} onChange={e=>setNewUser(u=>({...u,name:e.target.value}))} />
            </div>
            <div className={s.field} style={{marginBottom:8}}>
              <label>Email</label>
              <input type="email" placeholder="email@company.com" value={newUser.email} onChange={e=>setNewUser(u=>({...u,email:e.target.value}))} />
            </div>
            <div className={s.field} style={{marginBottom:8}}>
              <label>Password</label>
              <input type="password" placeholder="Password" value={newUser.password} onChange={e=>setNewUser(u=>({...u,password:e.target.value}))} />
            </div>
            <div className={s.field} style={{marginBottom:12}}>
              <label>Role</label>
              <select className={s.sel} value={newUser.role} onChange={e=>setNewUser(u=>({...u,role:e.target.value}))}>
                <option value="member">Member</option>
                <option value="admin">Admin</option>
              </select>
            </div>
            <button className={s.btnOrange} onClick={addUser}>+ Add User</button>
          </div>
        </div>
      </div>
    </div>
  )
}
