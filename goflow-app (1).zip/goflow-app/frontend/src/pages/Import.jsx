import { useState, useRef } from 'react'
import api from '../hooks/useApi.js'
import s from './Pages.module.css'

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function DropZone({ label, icon, note, onFile }) {
  const [drag, setDrag] = useState(false)
  const ref = useRef()
  return (
    <div
      className={`${s.dropZone} ${drag ? s.dragOver : ''}`}
      onDragOver={e => { e.preventDefault(); setDrag(true) }}
      onDragLeave={() => setDrag(false)}
      onDrop={e => { e.preventDefault(); setDrag(false); onFile(e.dataTransfer.files[0]) }}
      onClick={() => ref.current.click()}
    >
      <input ref={ref} type="file" accept=".xlsx,.csv" style={{display:'none'}} onChange={e => onFile(e.target.files[0])} />
      <div className={s.dropIcon}>{icon}</div>
      <div className={s.dropLabel}>{label}</div>
      <div className={s.dropNote}>{note}</div>
    </div>
  )
}

export default function Import() {
  const [month, setMonth] = useState(new Date().getMonth()+1)
  const [year, setYear] = useState(new Date().getFullYear())
  const [msg, setMsg] = useState('')
  const [err, setErr] = useState('')
  const [preview, setPreview] = useState(null)

  const flash = (m, isErr) => {
    if (isErr) { setErr(m); setTimeout(() => setErr(''), 4000) }
    else { setMsg(m); setTimeout(() => setMsg(''), 4000) }
  }

  const importPL = async file => {
    const form = new FormData()
    form.append('file', file)
    form.append('month', month)
    form.append('year', year)
    try {
      const token = localStorage.getItem('gf_token')
      const res = await fetch('/api/import/pl', { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:form })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      flash(`✅ Imported ${data.imported} rows for ${MONTHS[month-1]} ${year}`)
    } catch(e) { flash(e.message, true) }
  }

  const importVel = async file => {
    const form = new FormData()
    form.append('file', file)
    try {
      const token = localStorage.getItem('gf_token')
      const res = await fetch('/api/import/velocity', { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:form })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      flash(`✅ Updated velocity for ${data.imported} items`)
    } catch(e) { flash(e.message, true) }
  }

  const importSOH = async file => {
    const form = new FormData()
    form.append('file', file)
    try {
      const token = localStorage.getItem('gf_token')
      const res = await fetch('/api/import/soh', { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:form })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      flash(`✅ Updated stock on hand for ${data.imported} items`)
    } catch(e) { flash(e.message, true) }
  }

  const previewFile = async file => {
    const form = new FormData()
    form.append('file', file)
    try {
      const token = localStorage.getItem('gf_token')
      const res = await fetch('/api/import/preview', { method:'POST', headers:{ Authorization:`Bearer ${token}` }, body:form })
      const data = await res.json()
      setPreview(data)
    } catch(e) { flash(e.message, true) }
  }

  return (
    <div className={s.page}>
      <h1 className={s.title}>📥 Import Data</h1>
      <p className={s.sub}>Upload GoFlow exports to update inventory, velocity, and sales history</p>

      {msg && <div className={s.success}>{msg}</div>}
      {err && <div className={s.error}>{err}</div>}

      <div className={s.importGrid}>
        <div className={s.card}>
          <h3 className={s.cardTitle}>📊 GoFlow P&L Export</h3>
          <p className={s.cardSub}>Monthly sales data for trend calculations. Select month/year first.</p>
          <div className={s.monthRow}>
            <div className={s.field}>
              <label>Month</label>
              <select value={month} onChange={e => setMonth(+e.target.value)} className={s.sel}>
                {MONTHS.map((m,i) => <option key={i} value={i+1}>{m}</option>)}
              </select>
            </div>
            <div className={s.field}>
              <label>Year</label>
              <input type="number" value={year} onChange={e => setYear(+e.target.value)} style={{width:80}} />
            </div>
          </div>
          <DropZone icon="📄" label="Drop P&L export here" note=".xlsx or .csv · GoFlow format" onFile={importPL} />
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>⚡ Velocity Data</h3>
          <p className={s.cardSub}>Upload 7/30/90-day velocity report from Amazon or GoFlow.</p>
          <DropZone icon="⚡" label="Drop velocity report here" note=".xlsx or .csv · Item, 7-day, 30-day, 90-day cols" onFile={importVel} />
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>📦 Stock on Hand</h3>
          <p className={s.cardSub}>Upload current inventory levels from your warehouse system.</p>
          <DropZone icon="📦" label="Drop SOH report here" note=".xlsx or .csv · Item, Inventory cols" onFile={importSOH} />
        </div>

        <div className={s.card}>
          <h3 className={s.cardTitle}>🔍 Preview File</h3>
          <p className={s.cardSub}>Preview any Excel/CSV file before importing to check column names.</p>
          <DropZone icon="🔍" label="Drop any file to preview" note="Shows first 5 rows and column names" onFile={previewFile} />
          {preview && (
            <div className={s.previewBox}>
              <div style={{marginBottom:8, fontSize:12, color:'var(--muted)'}}>
                {preview.rows} rows · Columns: {preview.columns.join(', ')}
              </div>
              <pre className={s.previewPre}>{JSON.stringify(preview.preview, null, 2)}</pre>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
