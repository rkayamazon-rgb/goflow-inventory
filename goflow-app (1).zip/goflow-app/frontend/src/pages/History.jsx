import { useState, useEffect } from 'react'
import api from '../hooks/useApi.js'
import s from './Pages.module.css'

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

export default function History() {
  const [summary, setSummary] = useState([])

  useEffect(() => { api.get('/trends/history/summary').then(setSummary) }, [])

  return (
    <div className={s.page}>
      <h1 className={s.title}>📋 P&L History</h1>
      <p className={s.sub}>Monthly sales history used for seasonal trend calculations. Add data via Import.</p>

      {summary.length === 0
        ? <div className={s.emptyState}>
            <div style={{fontSize:40,marginBottom:12}}>📋</div>
            <div>No P&L history loaded yet</div>
            <div style={{fontSize:12,color:'var(--muted)',marginTop:6}}>Go to Import Data to upload your GoFlow P&L exports</div>
          </div>
        : <div className={s.tableWrap}>
            <table className={s.table}>
              <thead>
                <tr>
                  <th>Month</th><th>Year</th><th>Items</th>
                  <th>Total Units</th><th>Total Sales</th><th>Total Profit</th><th>Margin</th>
                </tr>
              </thead>
              <tbody>
                {summary.map(row => (
                  <tr key={`${row.year}-${row.month}`}>
                    <td><span className={s.badgeBlue}>{MONTHS[row.month-1]}</span></td>
                    <td className={s.bold}>{row.year}</td>
                    <td>{row.item_count}</td>
                    <td className={s.bold}>{(row.total_qty||0).toLocaleString()}</td>
                    <td style={{color:'var(--green)',fontWeight:600}}>${(row.total_sales||0).toLocaleString()}</td>
                    <td style={{color:'var(--blue)'}}>${(row.total_profit||0).toLocaleString()}</td>
                    <td className={s.muted}>
                      {row.total_sales > 0 ? Math.round(row.total_profit/row.total_sales*100)+'%' : '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>}
    </div>
  )
}
