import { useState, useEffect, useMemo } from 'react'
import api from '../hooks/useApi.js'
import s from './Dashboard.module.css'

const MONTHS = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

function Badge({ type, children }) {
  const cls = { red:'red', green:'green', yellow:'yellow', blue:'blue', gray:'gray', orange:'orange', purple:'purple' }
  return <span className={`${s.badge} ${s[cls[type]||'gray']}`}>{children}</span>
}

function TrendCell({ pct }) {
  if (pct === null || pct === undefined) return <span className={s.muted}>—</span>
  const p = Math.round(pct * 100)
  const cls = pct > 0.1 ? s.tPos : pct < -0.1 ? s.tNeg : s.tFlat
  return <span className={cls}>{p >= 0 ? '+' : ''}{p}%</span>
}

function StockCell({ item }) {
  if (item.overstock) return <span className={s.overstock}>🔴 {item.days_on_hand}d</span>
  if (!item.velocity_per_day) return <Badge type="gray">No vel.</Badge>
  if (item.stockout_risk) return <Badge type="red">⚠️ At risk</Badge>
  const d = item.days_on_hand
  if (d < 14) return <Badge type="red">{d}d</Badge>
  if (d < 30) return <Badge type="yellow">{d}d</Badge>
  return <Badge type="green">{d}d</Badge>
}

export default function Dashboard() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')
  const [sort, setSort] = useState({ key: 'item_number', dir: 1 })

  useEffect(() => {
    api.get('/inventory').then(setItems).finally(() => setLoading(false))
  }, [])

  const filtered = useMemo(() => {
    return items
      .filter(i => {
        const q = search.toLowerCase()
        if (q && !i.item_number?.toLowerCase().includes(q) &&
            !i.product_name?.toLowerCase().includes(q) &&
            !(i.vendor||'').toLowerCase().includes(q)) return false
        if (filter === 'stockout') return i.stockout_risk
        if (filter === 'overstock') return i.overstock
        if (filter === 'trend_up') return i.trend_pct > 0.1
        if (filter === 'trend_down') return i.trend_pct < -0.1
        if (filter === 'no_vel') return !i.velocity_per_day
        return true
      })
      .sort((a, b) => {
        const av = a[sort.key] ?? ''; const bv = b[sort.key] ?? ''
        return (typeof av === 'number' ? (av - bv) : String(av).localeCompare(String(bv))) * sort.dir
      })
  }, [items, search, filter, sort])

  const stats = useMemo(() => ({
    total: items.length,
    stockout: items.filter(i => i.stockout_risk).length,
    overstock: items.filter(i => i.overstock).length,
    trend_up: items.filter(i => i.trend_pct > 0.1).length,
  }), [items])

  const sortBy = key => setSort(s => ({ key, dir: s.key === key ? -s.dir : 1 }))
  const arr = k => sort.key === k ? (sort.dir === 1 ? ' ↑' : ' ↓') : ''

  if (loading) return <div className={s.center}><span className="spin" style={{fontSize:28}}>⟳</span></div>

  return (
    <div className={s.page}>
      <div className={s.header}>
        <div>
          <h1 className={s.title}>Inventory Dashboard</h1>
          <p className={s.sub}>{items.length} items · Updated today</p>
        </div>
      </div>

      <div className={s.stats}>
        {[
          { label: 'Total Items', value: stats.total, color: 'blue' },
          { label: 'Stockout Risk', value: stats.stockout, color: 'red', sub: 'within window' },
          { label: 'Overstock', value: stats.overstock, color: 'yellow', sub: '>180 days' },
          { label: 'Trend Up', value: stats.trend_up, color: 'green', sub: '>+10% seasonal' },
        ].map(c => (
          <div key={c.label} className={`${s.statCard} ${s[c.color]}`}>
            <div className={s.statLabel}>{c.label}</div>
            <div className={s.statValue}>{c.value}</div>
            {c.sub && <div className={s.statSub}>{c.sub}</div>}
          </div>
        ))}
      </div>

      <div className={s.tableWrap}>
        <div className={s.toolbar}>
          <input
            className={s.search}
            placeholder="🔍 Search item #, name, vendor..."
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
          <select className={s.filterSel} value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="all">All items</option>
            <option value="stockout">⚠️ Stockout risk</option>
            <option value="overstock">🔴 Overstock (&gt;180d)</option>
            <option value="trend_up">📈 Trend up (&gt;10%)</option>
            <option value="trend_down">📉 Trend down</option>
            <option value="no_vel">⚡ No velocity</option>
          </select>
          <span className={s.count}>{filtered.length} items</span>
        </div>

        <div className={s.tableScroll}>
          <table className={s.table}>
            <thead>
              <tr>
                <th onClick={() => sortBy('item_number')}>Item #{arr('item_number')}</th>
                <th onClick={() => sortBy('product_name')}>Product Name{arr('product_name')}</th>
                <th>Vendor</th>
                <th onClick={() => sortBy('stock_on_hand')}>SOH{arr('stock_on_hand')}</th>
                <th onClick={() => sortBy('velocity_per_day')}>Vel/day{arr('velocity_per_day')}</th>
                <th>Win. Demand</th>
                <th>Incoming POs</th>
                <th onClick={() => sortBy('net_balance')}>Net Balance{arr('net_balance')}</th>
                <th>Stock Status</th>
                <th onClick={() => sortBy('first_oos_day')}>First OOS{arr('first_oos_day')}</th>
                <th onClick={() => sortBy('trend_pct')}>Trend %{arr('trend_pct')}</th>
                <th>Adj. Reorder</th>
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr><td colSpan={12} className={s.empty}>No items found</td></tr>
              ) : filtered.map(item => (
                <tr key={item.item_number} className={item.overstock ? s.rowOverstock : item.stockout_risk ? s.rowRisk : ''}>
                  <td><span className={s.itemNum}>{item.item_number}</span></td>
                  <td className={s.nameCell}>{item.product_name}</td>
                  <td><Badge type="gray">{item.vendor || '—'}</Badge></td>
                  <td className={s.num}>{(item.stock_on_hand||0).toLocaleString()}</td>
                  <td className={s.num}>{item.velocity_per_day ? item.velocity_per_day.toFixed(2) : <span className={s.muted}>—</span>}</td>
                  <td className={s.num}>{(item.window_demand||0).toLocaleString()}</td>
                  <td className={s.num}>
                    {item.incoming_pos > 0
                      ? <span className={s.posNum}>+{(item.incoming_pos).toLocaleString()}</span>
                      : <span className={s.muted}>—</span>}
                  </td>
                  <td className={s.num}>
                    <span className={(item.net_balance||0) < 0 ? s.negNum : s.posNum}>
                      {(item.net_balance||0).toLocaleString()}
                    </span>
                  </td>
                  <td><StockCell item={item} /></td>
                  <td className={s.num}>
                    {item.first_oos_day != null ? `Day ${item.first_oos_day}` : <span className={s.muted}>N/A</span>}
                  </td>
                  <td><TrendCell pct={item.trend_pct} /></td>
                  <td className={s.num}>
                    {item.adj_reorder != null
                      ? <span className={item.adj_reorder >= 0 ? s.posNum : s.negNum}>
                          {item.adj_reorder >= 0 ? '+' : ''}{(item.adj_reorder).toLocaleString()}
                        </span>
                      : <span className={s.muted}>—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
