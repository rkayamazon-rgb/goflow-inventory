const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

const db = new Database(path.join(__dirname, '../data.db'));

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT,
    role TEXT DEFAULT 'member',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_number TEXT UNIQUE NOT NULL,
    product_name TEXT,
    vendor TEXT,
    stock_on_hand REAL DEFAULT 0,
    velocity_per_day REAL DEFAULT 0,
    velocity_7day REAL,
    velocity_30day REAL,
    velocity_90day REAL,
    incoming_pos REAL DEFAULT 0,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS trend_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_number TEXT NOT NULL,
    month INTEGER NOT NULL,
    real_ratio REAL,
    estimated_ratio REAL,
    type TEXT,
    source_year INTEGER DEFAULT 2025,
    UNIQUE(item_number, month)
  );

  CREATE TABLE IF NOT EXISTS trend_overrides (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_number TEXT UNIQUE NOT NULL,
    borrow_from TEXT NOT NULL,
    notes TEXT,
    created_by TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS pl_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    item_number TEXT NOT NULL,
    month INTEGER NOT NULL,
    year INTEGER NOT NULL,
    sales_qty INTEGER DEFAULT 0,
    sales_amount REAL DEFAULT 0,
    profit REAL DEFAULT 0,
    refund_qty INTEGER DEFAULT 0,
    UNIQUE(item_number, month, year)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Seed default settings
const defaults = [
  ['forecast_start_day', '1'],
  ['forecast_end_day', '90'],
  ['overstock_threshold_days', '180'],
  ['velocity_from', ''],
  ['velocity_to', ''],
  ['velocity_mode', 'Highest'],
];
const insertSetting = db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)');
defaults.forEach(([k, v]) => insertSetting.run(k, v));

// Seed admin user if not exists
const existing = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@company.com');
if (!existing) {
  db.prepare('INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)').run(
    'admin@company.com', bcrypt.hashSync('admin123', 10), 'Admin', 'admin'
  );
  db.prepare('INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)').run(
    'team@company.com', bcrypt.hashSync('team123', 10), 'Team Member', 'member'
  );
  console.log('Default users created');
}

module.exports = db;
