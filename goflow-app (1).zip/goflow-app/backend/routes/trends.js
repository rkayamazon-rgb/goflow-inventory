const router = require('express').Router();
const auth = require('../middleware/auth');
const db = require('../db');

// ── Trend Data ─────────────────────────────────────────────────────────────
router.get('/data', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM trend_data ORDER BY item_number, month').all();
  res.json(rows);
});

router.post('/data/bulk', auth, (req, res) => {
  const rows = req.body;
  const upsert = db.prepare(`
    INSERT OR REPLACE INTO trend_data (item_number, month, real_ratio, estimated_ratio, type, source_year)
    VALUES (?, ?, ?, ?, ?, ?)
  `);
  const insertMany = db.transaction((rows) => {
    rows.forEach(r => upsert.run(r.item_number, r.month, r.real_ratio, r.estimated_ratio, r.type, r.source_year || 2025));
  });
  insertMany(rows);
  res.json({ inserted: rows.length });
});

// ── Trend Overrides ────────────────────────────────────────────────────────
router.get('/overrides', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM trend_overrides ORDER BY item_number').all());
});

router.post('/overrides', auth, (req, res) => {
  const { item_number, borrow_from, notes } = req.body;
  if (!item_number || !borrow_from) return res.status(400).json({ error: 'item_number and borrow_from required' });
  db.prepare(`INSERT OR REPLACE INTO trend_overrides (item_number, borrow_from, notes, created_by) VALUES (?, ?, ?, ?)`)
    .run(item_number, borrow_from, notes || '', req.user.name || req.user.email);
  res.json({ message: 'Override saved' });
});

router.delete('/overrides/:itemNumber', auth, (req, res) => {
  db.prepare('DELETE FROM trend_overrides WHERE item_number = ?').run(req.params.itemNumber);
  res.json({ message: 'Deleted' });
});

// ── P&L History ────────────────────────────────────────────────────────────
router.get('/history', auth, (req, res) => {
  const rows = db.prepare('SELECT * FROM pl_history ORDER BY year DESC, month DESC, item_number').all();
  res.json(rows);
});

router.get('/history/summary', auth, (req, res) => {
  const rows = db.prepare(`
    SELECT year, month, COUNT(*) as item_count, 
           SUM(sales_qty) as total_qty, SUM(sales_amount) as total_sales,
           SUM(profit) as total_profit
    FROM pl_history GROUP BY year, month ORDER BY year DESC, month DESC
  `).all();
  res.json(rows);
});

router.post('/history/bulk', auth, (req, res) => {
  const rows = req.body;
  const upsert = db.prepare(`
    INSERT OR REPLACE INTO pl_history (item_number, month, year, sales_qty, sales_amount, profit, refund_qty)
    VALUES (?, ?, ?, ?, ?, ?, ?)
  `);
  const insertMany = db.transaction((rows) => {
    rows.forEach(r => upsert.run(r.item_number, r.month, r.year, r.sales_qty || 0, r.sales_amount || 0, r.profit || 0, r.refund_qty || 0));
  });
  insertMany(rows);
  res.json({ inserted: rows.length });
});

router.delete('/history/:year/:month', auth, (req, res) => {
  db.prepare('DELETE FROM pl_history WHERE year = ? AND month = ?').run(req.params.year, req.params.month);
  res.json({ message: 'Deleted' });
});

module.exports = router;
