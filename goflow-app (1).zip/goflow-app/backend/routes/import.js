const router = require('express').Router();
const auth = require('../middleware/auth');
const multer = require('multer');
const XLSX = require('xlsx');
const db = require('../db');

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 20 * 1024 * 1024 } });

function parseSheet(buffer, filename) {
  const wb = XLSX.read(buffer, { type: 'buffer' });
  const ws = wb.Sheets[wb.SheetNames[0]];
  return XLSX.utils.sheet_to_json(ws, { defval: '' });
}

// Import GoFlow P&L — detects columns automatically
router.post('/pl', auth, upload.single('file'), (req, res) => {
  try {
    const rows = parseSheet(req.file.buffer, req.file.originalname);
    const month = parseInt(req.body.month);
    const year = parseInt(req.body.year);
    if (!month || !year) return res.status(400).json({ error: 'month and year required in form data' });

    const upsert = db.prepare(`
      INSERT OR REPLACE INTO pl_history (item_number, month, year, sales_qty, sales_amount, profit, refund_qty)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    let imported = 0;
    const insertMany = db.transaction((rows) => {
      rows.forEach(row => {
        const item = String(row['Item'] || row['item'] || row['Item Number'] || row['item_number'] || '').trim();
        const qty = parseFloat(row['Sales Qty'] || row['sales_qty'] || row['Qty'] || 0);
        const sales = parseFloat(row['Sales'] || row['sales'] || row['Revenue'] || 0);
        const profit = parseFloat(row['Profit'] || row['profit'] || 0);
        const refund = Math.abs(parseFloat(row['Refund Qty'] || row['refund_qty'] || 0));
        if (item && sales > 0) {
          upsert.run(item, month, year, qty, sales, profit, refund);
          imported++;
        }
      });
    });
    insertMany(rows);
    res.json({ imported, total_rows: rows.length });
  } catch (e) {
    res.status(400).json({ error: 'Parse error: ' + e.message });
  }
});

// Import velocity data
router.post('/velocity', auth, upload.single('file'), (req, res) => {
  try {
    const rows = parseSheet(req.file.buffer, req.file.originalname);
    const upsert = db.prepare(`
      INSERT OR REPLACE INTO items (item_number, product_name, velocity_per_day, velocity_7day, velocity_30day, velocity_90day, updated_at)
      VALUES (?, COALESCE((SELECT product_name FROM items WHERE item_number = ?), ?), ?, ?, ?, ?, CURRENT_TIMESTAMP)
    `);

    let imported = 0;
    db.transaction((rows) => {
      rows.forEach(row => {
        const item = String(row['Item'] || row['Item Number'] || row['item_number'] || '').trim();
        const v7 = parseFloat(row['7 Day'] || row['7day'] || row['vel_7day'] || 0);
        const v30 = parseFloat(row['30 Day'] || row['30day'] || row['vel_30day'] || 0);
        const v90 = parseFloat(row['90 Day'] || row['90day'] || row['vel_90day'] || 0);
        const name = String(row['Product Name'] || row['Name'] || '').trim();
        if (item) {
          const vel = Math.max(v7, v30, v90) || v30 || v7 || v90;
          upsert.run(item, item, name, vel, v7, v30, v90);
          imported++;
        }
      });
    })(rows);
    res.json({ imported });
  } catch (e) {
    res.status(400).json({ error: 'Parse error: ' + e.message });
  }
});

// Import SOH (stock on hand)
router.post('/soh', auth, upload.single('file'), (req, res) => {
  try {
    const rows = parseSheet(req.file.buffer, req.file.originalname);
    let imported = 0;
    db.transaction((rows) => {
      rows.forEach(row => {
        const item = String(row['Item'] || row['item_number'] || '').trim();
        const soh = parseFloat(row['Inventory'] || row['Stock'] || row['On Hand'] || row['soh'] || 0);
        const pos = parseFloat(row['Incoming'] || row['PO'] || row['incoming_pos'] || 0);
        if (item) {
          db.prepare(`INSERT INTO items (item_number, stock_on_hand, incoming_pos, updated_at) 
            VALUES (?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(item_number) DO UPDATE SET stock_on_hand = ?, incoming_pos = ?, updated_at = CURRENT_TIMESTAMP`)
            .run(item, soh, pos, soh, pos);
          imported++;
        }
      });
    })(rows);
    res.json({ imported });
  } catch (e) {
    res.status(400).json({ error: 'Parse error: ' + e.message });
  }
});

// Preview file without importing
router.post('/preview', auth, upload.single('file'), (req, res) => {
  try {
    const rows = parseSheet(req.file.buffer, req.file.originalname);
    res.json({ rows: rows.length, columns: Object.keys(rows[0] || {}), preview: rows.slice(0, 5) });
  } catch (e) {
    res.status(400).json({ error: 'Parse error: ' + e.message });
  }
});

module.exports = router;
