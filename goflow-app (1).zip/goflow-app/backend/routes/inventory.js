const router = require('express').Router();
const auth = require('../middleware/auth');
const db = require('../db');

function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  return Object.fromEntries(rows.map(r => [r.key, r.value]));
}

function calcItem(item, settings) {
  const forecastDays = parseInt(settings.forecast_end_day) - parseInt(settings.forecast_start_day) + 1;
  const overstockDays = parseInt(settings.overstock_threshold_days) || 180;
  const vel = item.velocity_per_day || 0;
  const soh = item.stock_on_hand || 0;
  const pos = item.incoming_pos || 0;
  const windowDemand = vel * forecastDays;
  const netBalance = soh + pos - windowDemand;
  const daysOnHand = vel > 0 ? soh / vel : 9999;
  const firstOOS = vel > 0 ? Math.floor(soh / vel) : null;
  const stockoutRisk = firstOOS !== null && firstOOS <= parseInt(settings.forecast_end_day);
  const overstock = vel > 0 && daysOnHand > overstockDays;

  // Get trend data
  const trendRows = db.prepare(
    'SELECT month, estimated_ratio FROM trend_data WHERE item_number = ?'
  ).all(item.item_number);
  
  // Check override
  const override = db.prepare(
    'SELECT borrow_from FROM trend_overrides WHERE item_number = ?'
  ).get(item.item_number);
  
  const effectiveItem = override ? override.borrow_from : item.item_number;
  const effectiveTrend = override
    ? db.prepare('SELECT month, estimated_ratio FROM trend_data WHERE item_number = ?').all(effectiveItem)
    : trendRows;

  // Calculate forecast midpoint month
  const today = new Date();
  const forecastMid = new Date(today);
  forecastMid.setDate(today.getDate() + Math.round((parseInt(settings.forecast_start_day) + parseInt(settings.forecast_end_day)) / 2) - 1);
  const fMonth = forecastMid.getMonth() + 1;

  // Velocity period
  let vMonth = null;
  if (settings.velocity_from && settings.velocity_to) {
    const vMid = new Date((new Date(settings.velocity_from).getTime() + new Date(settings.velocity_to).getTime()) / 2);
    vMonth = vMid.getMonth() + 1;
  }

  const fRatio = effectiveTrend.find(r => r.month === fMonth)?.estimated_ratio;
  const vRatio = vMonth ? effectiveTrend.find(r => r.month === vMonth)?.estimated_ratio : null;

  let trendPct = null;
  if (fRatio) {
    if (vRatio) trendPct = fRatio / vRatio - 1;
    else {
      const allRatios = effectiveTrend.map(r => r.estimated_ratio).filter(Boolean);
      if (allRatios.length) trendPct = fRatio - (allRatios.reduce((a, b) => a + b, 0) / allRatios.length);
    }
  }

  const adjReorder = trendPct !== null ? Math.round(windowDemand * trendPct) : null;

  return {
    ...item,
    window_demand: Math.round(windowDemand),
    net_balance: Math.round(netBalance),
    days_on_hand: Math.round(daysOnHand),
    first_oos_day: firstOOS,
    stockout_risk: stockoutRisk,
    overstock,
    trend_pct: trendPct,
    adj_reorder: adjReorder,
    has_override: !!override,
    override_from: override?.borrow_from || null,
  };
}

router.get('/', auth, (req, res) => {
  const items = db.prepare('SELECT * FROM items ORDER BY item_number').all();
  const settings = getSettings();
  res.json(items.map(i => calcItem(i, settings)));
});

router.post('/', auth, (req, res) => {
  const { item_number, product_name, vendor, stock_on_hand, velocity_per_day, velocity_7day, velocity_30day, velocity_90day, incoming_pos } = req.body;
  try {
    db.prepare(`INSERT OR REPLACE INTO items 
      (item_number, product_name, vendor, stock_on_hand, velocity_per_day, velocity_7day, velocity_30day, velocity_90day, incoming_pos, updated_at)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)`)
      .run(item_number, product_name, vendor, stock_on_hand, velocity_per_day, velocity_7day, velocity_30day, velocity_90day, incoming_pos);
    res.json({ message: 'Item saved' });
  } catch (e) {
    res.status(400).json({ error: e.message });
  }
});

router.put('/:itemNumber', auth, (req, res) => {
  const fields = ['product_name','vendor','stock_on_hand','velocity_per_day','velocity_7day','velocity_30day','velocity_90day','incoming_pos'];
  const updates = fields.filter(f => req.body[f] !== undefined);
  if (!updates.length) return res.status(400).json({ error: 'No fields to update' });
  const sql = `UPDATE items SET ${updates.map(f => `${f} = ?`).join(', ')}, updated_at = CURRENT_TIMESTAMP WHERE item_number = ?`;
  db.prepare(sql).run(...updates.map(f => req.body[f]), req.params.itemNumber);
  res.json({ message: 'Updated' });
});

router.get('/settings', auth, (req, res) => res.json(getSettings()));

router.put('/settings/update', auth, (req, res) => {
  const upsert = db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)');
  Object.entries(req.body).forEach(([k, v]) => upsert.run(k, String(v)));
  res.json(getSettings());
});

router.get('/stats', auth, (req, res) => {
  const items = db.prepare('SELECT * FROM items').all();
  const settings = getSettings();
  const enriched = items.map(i => calcItem(i, settings));
  res.json({
    total: enriched.length,
    stockout: enriched.filter(i => i.stockout_risk).length,
    overstock: enriched.filter(i => i.overstock).length,
    trend_up: enriched.filter(i => i.trend_pct > 0.1).length,
    trend_down: enriched.filter(i => i.trend_pct < -0.1).length,
    zero_velocity: enriched.filter(i => !i.velocity_per_day).length,
  });
});

module.exports = router;
