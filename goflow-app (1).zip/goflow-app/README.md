# GoFlow Inventory Manager

Full-stack inventory management web app with seasonal trend analysis.

## Tech Stack
- **Frontend:** React + Vite + CSS Modules
- **Backend:** Node.js + Express
- **Database:** SQLite (file-based, no external DB needed)
- **Auth:** JWT tokens

## Default Login
- Admin: `admin@company.com` / `admin123`
- Team:  `team@company.com` / `team123`

---

## Run Locally

```bash
# 1. Install dependencies
cd backend && npm install
cd ../frontend && npm install

# 2. Start backend (port 3001)
cd backend && node index.js

# 3. Start frontend (port 5173) — in a new terminal
cd frontend && npx vite

# Open http://localhost:5173
```

---

## Deploy to Railway (Recommended — Free tier available)

1. Go to https://railway.app and sign up
2. Click "New Project" → "Deploy from GitHub repo"
3. Push this folder to a GitHub repo first:
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin https://github.com/YOUR_USERNAME/goflow-inventory
   git push -u origin main
   ```
4. In Railway: select your repo → it auto-detects Node.js
5. Add environment variable: `JWT_SECRET` = any long random string
6. Railway gives you a public URL automatically

**Before deploying:** Build the frontend first:
```bash
cd frontend && npm run build
```
The backend serves the built frontend from `frontend/dist/`.

---

## Deploy to Render (Also free)

1. Go to https://render.com
2. New Web Service → connect GitHub repo
3. Build Command: `cd frontend && npm install && npm run build && cd ../backend && npm install`
4. Start Command: `node backend/index.js`
5. Add env var: `JWT_SECRET`

---

## Features
- 📊 **Dashboard** — sortable inventory table, stockout risk, trend %, overstock flags
- 🔀 **Trend Overrides** — assign seasonal curves from other items
- 📋 **P&L History** — view monthly sales data by month/year
- 📥 **Import** — drag & drop Excel/CSV for P&L, velocity, and SOH data
- ⚙️ **Settings** — forecast window, velocity dates, overstock threshold, team management

## Import Formats

### P&L Export (GoFlow)
Columns: `Item`, `Sales Qty`, `Sales`, `Profit`, `Refund Qty`

### Velocity Report
Columns: `Item`, `7 Day`, `30 Day`, `90 Day`, `Product Name`

### Stock on Hand
Columns: `Item`, `Inventory`, `Incoming` (optional)
